# Employee-Management-System
An Employee Management System using TypeScript,  HTML and CSS. It has following properties:
1. Clicking	on Create	Employee Type button	displays Create	Employee Type form	and	allows	the	system	to	add	new	type	of	employee.	Clicking	on	cancel	button	hides	the	respective	form.

2. Clicking	on Delete	Employee	Type	button	displays	Delete	Employee	Type form	and	allows	the	system	to	remove	existing	type	of	employee.	Clicking	on	cancel	button	hides	the	respective	form.

3. Employee	List	should	be	represented	with	two	tabs	(types	of	employees)	by	default.	One	tab	shows	list	of	managers	and	other	tab	displays	the	developer	list.	One	tab	should	be	selected	by	
default.	

4. User	can	select	the	type	of	employee	(Manager/Developer)	from	dropdown	menu	before	submitting.	

5. Name	and	Designations	needs	to	be	filled	before	adding	an	employee.

6. Selecting	an	employee	from	the	Employee	List	enables	Edit	and	Remove button. Clicking	on	Edit	button	displays	the	information	in	Add	Employee	form	and	Add	button	label	should	be	changed	to Update. Clicking	on	Remove	button	removes	the	employee	from	the	respective	list.	

7. Clicking	on	Add	button	from	the	Add	Employee	list,	add	the	employee	in	the	respective	tab.		

8. Clicking	on	Undo	button	removes	the	last	added	employee.	Undo	action	can	be	perform	for	the	last	three	added	employees.	
