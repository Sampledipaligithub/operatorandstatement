<!DOCTYPE html>
<html>
<head>

    <title>Employee portal</title>
</head>

<body>

    <div id="header">
       
        <div id="h1right">
            <h1>Ishita Chourasia</h1>
            <p1>I am from Indore. I am a final year student pursuing B.Tech at DAIICT, Gandhinagar. I am involved in programs that involve women in technology. I spend my free time listening to songs and playing volleyball. I love to explore new places.</p1>
        </div>
    </div>

    <div id="content">

     

            </div>

        

               

</body>
</html>

<button type="button">Click Me!</button>